package insurance;

public class DTO {
	
	//�������� ���̺�
	private String sno;
	private String sname;
	private String spass;
	private String bcd;
	private String srank;
	
	//�������� ���̺�
	private String bname;
	
	//���� ������� ���̺�
	
	private String ino;
	private String iname;
	private String iamount;
	private String idate;
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSpass() {
		return spass;
	}
	public void setSpass(String spass) {
		this.spass = spass;
	}
	public String getBcd() {
		return bcd;
	}
	public void setBcd(String bcd) {
		this.bcd = bcd;
	}
	public String getSrank() {
		return srank;
	}
	public void setSrank(String srank) {
		this.srank = srank;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getIno() {
		return ino;
	}
	public void setIno(String ino) {
		this.ino = ino;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getIamount() {
		return iamount;
	}
	public void setIamount(String iamount) {
		this.iamount = iamount;
	}
	public String getIdate() {
		return idate;
	}
	public void setIdate(String idate) {
		this.idate = idate;
	}

	
	
}
